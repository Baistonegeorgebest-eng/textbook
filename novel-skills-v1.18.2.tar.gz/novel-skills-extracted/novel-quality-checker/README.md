# novel-quality-checker

小说章节自动质检工具，可作为 PostWrite Hook 自动运行。

## 用法

```bash
# 基础用法
python3 checker.py chapter.txt

# 美化输出
python3 checker.py chapter.txt --pretty

# 指定平台/题材
python3 checker.py chapter.txt --platform fanqie --genre xianxia

# 指定配置文件
python3 checker.py chapter.txt --config config.yaml
```

## 检测项

| 检测项 | 说明 | 指标 |
|--------|------|------|
| 标点指纹 | 感叹号/省略号/逗号/句号密度 | 每千字出现次数 |
| 句式多样性 | 连续句式变化率 | 0~1 变化率 |
| 感官密度 | 五感分布（视/听/触/嗅/味） | 每万字感官句数 |
| 对话比例 | 引号内字符占比 | 百分比 |
| AI 模板检测 | 句号碎片、模糊表达、比喻过频 | 比率/每千字 |
| 禁用词冷却 | 高频词重复间隔 | 字符间距 |
| 长句比例 | 超过阈值的句子占比 | 百分比 |

## 输出格式

JSON 格式，每项包含：
- `value`: 具体数值
- `range`: 参考范围
- `status`: `passed` / `warning` / `failed`

顶层 `overall` 字段为汇总状态。

## 退出码

| 码 | 含义 |
|----|------|
| 0  | 全部通过 |
| 1  | 有警告 |
| 2  | 有失败 |

## 配置

编辑 `config.yaml` 调整阈值，支持按平台/题材覆盖。

## 作为 PostWrite Hook

在 OpenClaw 中配置为写后自动质检：

```yaml
# 在 skill 配置中添加
post_write_hooks:
  - name: novel-quality-check
    command: "python3 /path/to/checker.py {{file}} --pretty"
    trigger: "*.txt"
```

## 依赖

- Python 3.6+
- PyYAML（可选，用于加载 config.yaml；无则使用内置默认值）
