#!/usr/bin/env python3
"""
novel-quality-checker: 小说章节自动质检脚本
用法: python3 checker.py <chapter.txt> [--config config.yaml] [--platform fanqie] [--genre xianxia]
输出: JSON 格式质检报告
"""

import sys
import os
import re
import json
import argparse
from collections import defaultdict
from pathlib import Path

# ========== 感官关键词库 (extracted from extract-sensory.py) ==========
SENSORY_KEYWORDS = {
    "嗅觉": [
        "闻到", "闻着", "闻了", "嗅到", "嗅着", "气味", "味道", "香味", "香气",
        "臭味", "臭气", "腥味", "血腥味", "血腥气", "烟味", "焦味", "焦臭",
        "霉味", "腐臭", "酸臭", "恶臭", "清香", "幽香", "暗香", "浓香",
        "芳香", "芬芳", "刺鼻", "呛人", "腥甜", "腥臭", "铜腥", "铁锈味",
        "泥土味", "草木味", "花香", "果香", "肉香", "饭香", "菜香",
        "消毒水", "药味", "汗味", "体香", "香水味", "烟草味",
        "焚香", "檀香", "沉香", "龙涎", "麝香", "艾草",
        "松脂", "油脂", "油烟", "焦糊", "糊味",
    ],
    "味觉": [
        "尝到", "尝了", "尝着", "品尝", "品味", "口味",
        "甜味", "苦味", "酸味", "辣味", "咸味", "鲜味", "涩味",
        "甘甜", "苦涩", "酸涩", "辛辣", "咸涩", "鲜美",
        "入口", "入喉", "入腹", "舌尖", "舌面", "舌根",
        "咀嚼", "吞咽", "咽下", "吞下", "嚼着",
        "美味", "可口", "好吃", "难吃",
        "回味", "回甘", "余味", "齿颊留香",
        "麻辣", "香辣", "酸辣", "甜腻", "油腻",
        "果汁", "茶香", "酒香", "汤汁", "汤鲜",
    ],
    "触觉": [
        "触感", "触碰", "触摸", "抚摸", "抚过", "摩挲",
        "柔软", "坚硬", "粗糙", "光滑", "细腻", "温润",
        "冰凉", "冰冷", "滚烫", "灼热", "温热", "微凉",
        "刺痛", "灼痛", "酸痛", "胀痛", "隐隐作痛",
        "鸡皮疙瘩", "汗毛", "毛孔", "起了一层",
        "指尖", "掌心", "手心", "指腹", "指节",
        "握住", "捏住", "抓住", "攥住", "松开",
        "黏腻", "黏稠", "湿滑", "干燥", "潮湿",
        "弹性", "紧致", "绵软", "硬邦邦", "软绵绵",
        "颤抖", "发抖", "哆嗦", "战栗", "打颤",
        "风刮", "风吹", "雨打", "雨淋", "日晒",
        "寒冷", "炎热", "闷热", "凉爽", "刺骨",
    ],
    "听觉": [
        "听到", "听见", "听着", "声响", "声音",
        "轰鸣", "嗡鸣", "震颤", "震响", "回响",
        "脚步声", "心跳声", "呼吸声", "风声", "雨声",
        "鸟鸣", "虫鸣", "蛙声", "蝉鸣", "鸦啼",
        "剑鸣", "刀鸣", "枪响", "炮声", "爆炸声",
        "低语", "呢喃", "嘀咕", "呐喊", "咆哮", "嘶吼",
        "寂静", "安静", "喧闹", "嘈杂", "喧嚣",
        "咔哒", "噼啪", "叮当", "咣当", "砰", "嘭",
        "沙沙", "簌簌", "潺潺", "淙淙", "哗哗",
        "叮咚", "咕噜", "咯吱", "嘎吱",
    ],
    "视觉": [
        "看到", "看见", "望着", "盯着", "注视", "凝视",
        "目光", "视线", "眼中", "眼里", "眼底",
        "光芒", "光亮", "光辉", "闪烁", "闪耀", "耀眼",
        "黑暗", "漆黑", "昏暗", "灰暗", "阴暗",
        "红色", "蓝色", "绿色", "金色", "银色", "紫色",
        "碧绿", "湛蓝", "雪白", "赤红", "金黄",
        "晶莹", "剔透", "透明", "半透明", "朦胧",
        "轮廓", "身影", "身姿", "容貌", "面目",
        "天际", "地平线", "远处", "近处", "眼前",
    ],
}

# AI 模糊表达词
VAGUE_WORDS = [
    "某种", "似乎", "仿佛", "好像", "隐隐", "淡淡地",
    "一种说不清", "难以言喻", "莫名", "说不出的",
    "不知为何", "莫名其妙", "模模糊糊", "若隐若现",
    "隐隐约约", "恍惚", "依稀",
]

# ========== 默认配置 ==========
DEFAULT_CONFIG = {
    "punctuation": {
        "comma": {"min": 30, "max": 70},
        "period": {"min": 15, "max": 45},
        "exclamation": {"min": 0, "max": 8},
        "ellipsis": {"min": 0, "max": 5},
        "question": {"min": 0, "max": 6},
    },
    "sentence_diversity": {
        "min_change_rate": 0.35,
        "warning_change_rate": 0.25,
    },
    "sensory_density": {
        "min_total": 3,
        "warning_total": 1.5,
        "min_single": 0.2,
        "balance_ratio": 0.15,
    },
    "dialogue": {
        "min_ratio": 0.05,
        "max_ratio": 0.50,
        "warning_low": 0.08,
        "warning_high": 0.40,
    },
    "ai_template": {
        "fragment_threshold": 0.25,
        "fragment_critical": 0.40,
        "vague_word_threshold": 3.0,
        "vague_word_critical": 6.0,
        "metaphor_threshold": 1.5,
        "metaphor_critical": 3.0,
    },
    "forbidden_words": {
        "words": {
            "不禁": 500, "不由得": 500, "下意识": 800,
            "目光": 300, "微微": 400, "缓缓": 400,
            "淡淡": 400, "轻轻": 400, "默默": 500,
            "静静": 500, "心中一动": 1000,
            "嘴角微微上扬": 2000, "眼中闪过": 800,
            "深吸一口气": 1500,
        }
    },
    "long_sentence": {
        "threshold_chars": 50,
        "max_ratio": 0.30,
        "warning_ratio": 0.20,
    },
}


def load_config(config_path=None, platform=None, genre=None):
    """加载配置，支持平台/题材覆盖"""
    config = DEFAULT_CONFIG.copy()

    if config_path and os.path.exists(config_path):
        try:
            import yaml
            with open(config_path, 'r', encoding='utf-8') as f:
                raw = yaml.safe_load(f)

            # 合并默认配置
            if "default" in raw:
                _deep_merge(config, raw["default"])

            # 平台覆盖
            if platform and "platforms" in raw and platform in raw["platforms"]:
                _deep_merge(config, raw["platforms"][platform])

            # 题材覆盖
            if genre and "genres" in raw and genre in raw["genres"]:
                _deep_merge(config, raw["genres"][genre])
        except ImportError:
            pass  # yaml not available, use defaults
        except Exception:
            pass

    return config


def _deep_merge(base, override):
    """递归合并字典"""
    for k, v in override.items():
        if k in base and isinstance(base[k], dict) and isinstance(v, dict):
            _deep_merge(base[k], v)
        else:
            base[k] = v


def read_file(filepath):
    """读取文件，自动检测编码"""
    for enc in ['utf-8', 'gbk', 'gb18030', 'gb2312']:
        try:
            with open(filepath, 'r', encoding=enc) as f:
                return f.read()
        except (UnicodeDecodeError, UnicodeError):
            continue
    with open(filepath, 'rb') as f:
        return f.read().decode('utf-8', errors='replace')


def count_chars(text):
    """统计有效字符数（去除空白）"""
    return len(re.sub(r'\s', '', text))


def split_sentences(text):
    """按句号/感叹号/问号分句"""
    raw = re.split(r'[。！？]', text)
    return [s.strip() for s in raw if len(s.strip()) > 2]


# ========== 检测模块 ==========

def check_punctuation(text, chars, cfg):
    """a. 标点指纹"""
    comma = text.count('，')
    period = text.count('。')
    excl = text.count('！')
    ellipsis = text.count('……')
    question = text.count('？')

    def rate(n):
        return round(n / chars * 1000, 2) if chars else 0

    items = {}
    for name, key, count in [
        ("逗号密度", "comma", comma),
        ("句号密度", "period", period),
        ("感叹号密度", "exclamation", excl),
        ("省略号密度", "ellipsis", ellipsis),
        ("问号密度", "question", question),
    ]:
        val = rate(count)
        limits = cfg.get(key, {})
        lo, hi = limits.get("min", 0), limits.get("max", 999)
        status = "passed" if lo <= val <= hi else ("warning" if (val < lo * 0.7 or val > hi * 1.3) else "warning")
        if val < lo or val > hi:
            status = "warning" if abs(val - (lo if val < lo else hi)) < (hi - lo) * 0.3 else "failed"
            # Simplify: out of range = warning, far out = failed
            if val < lo * 0.5 or val > hi * 1.5:
                status = "failed"
            else:
                status = "warning"
        else:
            status = "passed"

        items[name] = {
            "value": val,
            "range": f"{lo}~{hi}",
            "unit": "每千字",
            "status": status,
        }

    return items


def check_sentence_diversity(text, cfg):
    """b. 句式多样性：连续句式变化率"""
    sentences = split_sentences(text)
    if len(sentences) < 3:
        return {"变化率": {"value": 0, "range": f">={cfg.get('min_change_rate', 0.35)}", "status": "warning", "note": "句子太少无法评估"}}

    # 用首字词性/结构做简化分类
    patterns = []
    for s in sentences:
        s = s.strip()
        if not s:
            patterns.append("empty")
            continue
        # 简化句式分类
        if re.match(r'^[""「]', s):
            patterns.append("dialogue")
        elif re.match(r'^[他她它我你]', s):
            patterns.append("subject_pronoun")
        elif re.match(r'^[一二三四五六七八九十百千万]', s):
            patterns.append("number")
        elif re.match(r'^[这时那此]', s):
            patterns.append("demonstrative")
        elif '，' in s and s.count('，') >= 2:
            patterns.append("complex")
        else:
            patterns.append("simple")

    # 计算相邻句式变化率
    changes = sum(1 for i in range(1, len(patterns)) if patterns[i] != patterns[i-1])
    rate = round(changes / (len(patterns) - 1), 3) if len(patterns) > 1 else 0

    min_rate = cfg.get("min_change_rate", 0.35)
    warn_rate = cfg.get("warning_change_rate", 0.25)

    if rate >= min_rate:
        status = "passed"
    elif rate >= warn_rate:
        status = "warning"
    else:
        status = "failed"

    return {"变化率": {"value": rate, "range": f">={min_rate}", "status": status}}


def check_sensory_density(text, chars, cfg):
    """c. 感官密度（五感分布）"""
    wan = chars / 10000 if chars else 0
    results = {}

    for sense_name, keywords in SENSORY_KEYWORDS.items():
        count = 0
        for kw in keywords:
            count += text.count(kw)
        per_wan = round(count / wan, 2) if wan else 0
        results[sense_name] = per_wan

    total = sum(results.values())
    min_total = cfg.get("min_total", 3)
    warn_total = cfg.get("warning_total", 1.5)

    # 平衡性检查
    vals = [v for v in results.values() if v > 0]
    balance_ok = True
    if len(vals) >= 2:
        ratio = min(vals) / max(vals)
        balance_ratio = cfg.get("balance_ratio", 0.15)
        balance_ok = ratio >= balance_ratio

    if total >= min_total and balance_ok:
        total_status = "passed"
    elif total >= warn_total:
        total_status = "warning"
    else:
        total_status = "failed"

    output = {
        "分布": {k: {"value": v, "unit": "每万字"} for k, v in results.items()},
        "总计": {"value": round(total, 2), "range": f">={min_total}", "status": total_status},
        "平衡": {"value": "平衡" if balance_ok else "失衡", "status": "passed" if balance_ok else "warning"},
    }
    return output


def check_dialogue_ratio(text, chars, cfg):
    """d. 对话比例"""
    # 用正则提取引号内容
    # 匹配中文引号 "" 「」 『』 和英文引号
    patterns = [
        r'\u201c[^\u201d]*\u201d',   # ""
        r'\u300c[^\u300d]*\u300d',   # 「」
        r'\u300e[^\u300f]*\u300f',   # 『』
        r'"[^"]*"',                   # ""
        r"'[^']*'",                   # ''
    ]
    dialogue_chars = 0
    for pat in patterns:
        for m in re.finditer(pat, text):
            content = m.group()[1:-1]  # 去掉引号本身
            dialogue_chars += len(re.sub(r'\s', '', content))

    ratio = round(dialogue_chars / chars, 4) if chars else 0

    min_r = cfg.get("min_ratio", 0.05)
    max_r = cfg.get("max_ratio", 0.50)
    warn_low = cfg.get("warning_low", 0.08)
    warn_high = cfg.get("warning_high", 0.40)

    if min_r <= ratio <= max_r:
        if ratio < warn_low or ratio > warn_high:
            status = "warning"
        else:
            status = "passed"
    else:
        status = "failed"

    return {"比例": {"value": ratio, "range": f"{min_r}~{max_r}", "status": status}}


def check_ai_template(text, chars, cfg):
    """e. AI 模板检测"""
    sentences = split_sentences(text)
    issues = {}

    # 1. 句号碎片：连续短句(<8字)占比
    short_count = sum(1 for s in sentences if len(re.sub(r'\s', '', s)) < 8)
    frag_ratio = round(short_count / len(sentences), 3) if sentences else 0
    frag_thresh = cfg.get("fragment_threshold", 0.25)
    frag_crit = cfg.get("fragment_critical", 0.40)

    if frag_ratio < frag_thresh:
        frag_status = "passed"
    elif frag_ratio < frag_crit:
        frag_status = "warning"
    else:
        frag_status = "failed"

    issues["句号碎片"] = {
        "value": frag_ratio,
        "threshold": frag_thresh,
        "status": frag_status,
        "detail": f"{short_count}/{len(sentences)}句为短句",
    }

    # 2. 模糊表达词频
    vague_count = sum(text.count(w) for w in VAGUE_WORDS)
    vague_per_k = round(vague_count / chars * 1000, 2) if chars else 0
    vague_thresh = cfg.get("vague_word_threshold", 3.0)
    vague_crit = cfg.get("vague_word_critical", 6.0)

    if vague_per_k < vague_thresh:
        vague_status = "passed"
    elif vague_per_k < vague_crit:
        vague_status = "warning"
    else:
        vague_status = "failed"

    issues["模糊表达"] = {
        "value": vague_per_k,
        "threshold": vague_thresh,
        "status": vague_status,
        "unit": "每千字",
    }

    # 3. "像"比喻频率
    metaphor_count = len(re.findall(r'像[^。！？]{2,20}', text))
    metaphor_per_k = round(metaphor_count / chars * 1000, 2) if chars else 0
    meta_thresh = cfg.get("metaphor_threshold", 1.5)
    meta_crit = cfg.get("metaphor_critical", 3.0)

    if metaphor_per_k < meta_thresh:
        meta_status = "passed"
    elif metaphor_per_k < meta_crit:
        meta_status = "warning"
    else:
        meta_status = "failed"

    issues["比喻频率"] = {
        "value": metaphor_per_k,
        "threshold": meta_thresh,
        "status": meta_status,
        "unit": "每千字",
    }

    return issues


def check_forbidden_words(text, cfg):
    """f. 禁用词冷却"""
    words_cfg = cfg.get("words", {})
    violations = []

    for word, cooldown in words_cfg.items():
        # 找到所有出现位置
        positions = []
        start = 0
        while True:
            idx = text.find(word, start)
            if idx == -1:
                break
            positions.append(idx)
            start = idx + len(word)

        if len(positions) < 2:
            continue

        # 检查相邻出现间隔
        for i in range(1, len(positions)):
            gap = positions[i] - positions[i-1]
            if gap < cooldown:
                violations.append({
                    "word": word,
                    "gap": gap,
                    "cooldown": cooldown,
                    "positions": [positions[i-1], positions[i]],
                })

    if not violations:
        status = "passed"
    elif len(violations) <= 2:
        status = "warning"
    else:
        status = "failed"

    return {
        "violations": violations,
        "count": len(violations),
        "status": status,
    }


def check_long_sentence(text, cfg):
    """g. 长句比例"""
    sentences = split_sentences(text)
    if not sentences:
        return {"比例": {"value": 0, "range": f"<={cfg.get('max_ratio', 0.30)}", "status": "passed"}}

    threshold = cfg.get("threshold_chars", 50)
    long_count = sum(1 for s in sentences if len(re.sub(r'\s', '', s)) > threshold)
    ratio = round(long_count / len(sentences), 3)

    max_r = cfg.get("max_ratio", 0.30)
    warn_r = cfg.get("warning_ratio", 0.20)

    if ratio <= warn_r:
        status = "passed"
    elif ratio <= max_r:
        status = "warning"
    else:
        status = "failed"

    return {
        "比例": {
            "value": ratio,
            "range": f"<={max_r}",
            "status": status,
            "detail": f"{long_count}/{len(sentences)}句超过{threshold}字",
        }
    }


# ========== 主函数 ==========

def run_checker(filepath, config_path=None, platform=None, genre=None):
    """运行全部检测，返回 JSON 报告"""
    cfg = load_config(config_path, platform, genre)

    text = read_file(filepath)
    text_clean = text.replace('\r\n', '\n').replace('\r', '\n')
    chars = count_chars(text_clean)

    if chars < 100:
        return {
            "file": filepath,
            "error": "文本过短（<100字），无法检测",
            "overall": "failed",
        }

    report = {
        "file": os.path.basename(filepath),
        "chars": chars,
        "checks": {},
    }

    # a. 标点指纹
    report["checks"]["punctuation"] = check_punctuation(text_clean, chars, cfg.get("punctuation", {}))

    # b. 句式多样性
    report["checks"]["sentence_diversity"] = check_sentence_diversity(text_clean, cfg.get("sentence_diversity", {}))

    # c. 感官密度
    report["checks"]["sensory_density"] = check_sensory_density(text_clean, chars, cfg.get("sensory_density", {}))

    # d. 对话比例
    report["checks"]["dialogue"] = check_dialogue_ratio(text_clean, chars, cfg.get("dialogue", {}))

    # e. AI 模板检测
    report["checks"]["ai_template"] = check_ai_template(text_clean, chars, cfg.get("ai_template", {}))

    # f. 禁用词冷却
    report["checks"]["forbidden_words"] = check_forbidden_words(text_clean, cfg.get("forbidden_words", {}))

    # g. 长句比例
    report["checks"]["long_sentence"] = check_long_sentence(text_clean, cfg.get("long_sentence", {}))

    # 汇总
    all_statuses = []
    for check_name, check_data in report["checks"].items():
        if isinstance(check_data, dict):
            if "status" in check_data:
                all_statuses.append(check_data["status"])
            else:
                for sub in check_data.values():
                    if isinstance(sub, dict) and "status" in sub:
                        all_statuses.append(sub["status"])

    if "failed" in all_statuses:
        report["overall"] = "failed"
    elif "warning" in all_statuses:
        report["overall"] = "warning"
    else:
        report["overall"] = "passed"

    failed_count = all_statuses.count("failed")
    warning_count = all_statuses.count("warning")
    passed_count = all_statuses.count("passed")
    report["summary"] = {
        "passed": passed_count,
        "warning": warning_count,
        "failed": failed_count,
    }

    return report


def main():
    parser = argparse.ArgumentParser(description="小说章节自动质检")
    parser.add_argument("input", help="章节 txt 文件路径")
    parser.add_argument("--config", default=None, help="配置文件路径 (YAML)")
    parser.add_argument("--platform", default=None, help="平台 (如 fanqie)")
    parser.add_argument("--genre", default=None, help="题材 (如 xianxia, urban)")
    parser.add_argument("--pretty", action="store_true", help="美化输出 JSON")
    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(json.dumps({"error": f"文件不存在: {args.input}"}, ensure_ascii=False))
        sys.exit(1)

    # 查找默认配置
    if args.config is None:
        default_cfg = Path(__file__).parent / "config.yaml"
        if default_cfg.exists():
            args.config = str(default_cfg)

    report = run_checker(args.input, args.config, args.platform, args.genre)

    indent = 2 if args.pretty else None
    print(json.dumps(report, ensure_ascii=False, indent=indent))

    # 退出码: 0=passed, 1=warning, 2=failed
    if report.get("overall") == "failed":
        sys.exit(2)
    elif report.get("overall") == "warning":
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
