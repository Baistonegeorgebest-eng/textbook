# novel-skills Changelog

## v1.18.2 — 2026-05-07

### 重构：expert-human-flavor（基于v4.4/v4.5协议）

**目标：** 将2987行的人味注入协议v4.4核心内容注入skill体系，解决"规则缺数据支撑+AI鉴别/退化预警缺失+分层加载缺失"三大问题。

**SKILL.md 变更（499行→410行）：**

| 新增内容 | 说明 |
|---------|------|
| §三.3.1 严肃度1-10标尺 | 摘要版（表格化），完整版在references/ |
| §四 质量分级摘要 | T1/T2/T3核心指标表 |
| §五 AI文字量化鉴别 | 7个量化指纹+快速检测流程 |
| §六 退化预警摘要 | 三种来源+核心阈值表 |

**保留/增强内容：**
- §零 协议解决问题（完整保留）
- §一 人味三层模型（完整保留）
- §三 基础人味层全部硬约束（完整保留§3.1-3.10）
- §七-九 种子写作法/扰动机制/感官优先级（完整保留）

**新增 references 文件：**

| 文件 | 行数 | 内容 | 来源 |
|------|------|------|------|
| `references/tier-prompts.md` | 160行 | T1/T2/T3完整prompt模板+质检指标 | v4.4 §四 |
| `references/quality-degradation.md` | 170行 | 人味指数13项+退化检测流程+严肃度-标点锚定表 | v4.4 §十 |
| `references/style-reference.md` | 389行 | 33本参考小说风格DNA+标点指纹+叙事方法论 | v4.4 §十二 |

**设计原则：**
1. 分层加载：核心410行每次必加载，references按需读取
2. 硬约束自包含：核心文件中的滑动窗口/严肃度/AI鉴别/退化阈值均可独立注入prompt
3. 对抗性设计：反AI三问用"尝试破坏"而非"确认合格"

### 新增：v1.18.2评估报告

- `novel-skills-v1.18.2-evaluation.md`：全体系71个skill扫描+内容老化度评估+下一步路线图

### 待办（v1.18.3）

- [ ] 废弃expert-human-flavor-tiers + expert-anti-ai-taste（内容已并入human-flavor）
- [ ] 更新expert-hook示例（注入v4.4开局模式）
- [ ] 更新expert-dialogue（注入四种博弈类型）
- [ ] 合并writing-style+style-learner为style-reference

---

## v1.18.1 — 2026-04-24

### 补回：封包铁律 skills（v1.10→v1.10.1 误删修复）

**背景**：v1.10 → v1.10.1 封包时，移除了5个"框架/工具类"skill。其中2个有实质内容且无替代品，被错误移除。本次补回。

**补回 skills：**

| skill | 行数 | 作用 | 补回理由 |
|-------|------|------|----------|
| skill-safety-protocol | 201行 | Skill写入安全规程（备份基准/写入验证/熔断） | 新agent无替代品，防止写入操作搞坏已有skill |
| skill-deployment-protocol | 224行 | Skill部署集成检查（路由树/依赖图/协同协议联动） | 与skill-safety-protocol配对，确保skill变更后框架完整 |

**不补回 skills（及理由）：**

| skill | 行数 | 理由 |
|-------|------|------|
| session-compactor | 365行 | 与AGENTS.md heartbeat机制 + context-manager重复 |
| skill-lazy-loader | 381行 | 耦合具体skill名称，版本迭代后易过时；待后续skill审查完再更新 |
| writing-assistant | 21行 | 纯壳子，被novel-writing-expert(474行)完全覆盖 |

**教训记录：**
> ⚠️ 封包时不能仅凭"是否为创作类skill"判断去留。框架/工具类skill需要评估：
> 1. 是否有独立价值（不与其他skill重复）
> 2. 新agent是否有替代能力
> 3. 移除后是否造成不可恢复的能力缺失
> 
> 本次 session-compactor 的误判就是因为把"小说进度快照"功能误认为已无替代品，
> 实际上 novel-memory-3layer 已有更精确的增量事实快照机制。
> 但 skill-safety-protocol 的"写入保护"能力确实没有替代品，属于误删。

### 封包铁律（新增）

> **每次封包前必须检查：**
> 1. skill-safety-protocol 存在 ✅
> 2. skill-deployment-protocol 存在 ✅
> 3. 两个skill的SKILL.md行数 ≥ 200行 ✅
> 
> 此铁律写入 CHANGELOG.md，后续封包必须继承。

---

## v1.18.0 — 2026-04-23

### 新增：人味协议v4.0拆分

- expert-human-flavor（499行）：三层人味模型 + 硬约束 + 缓冲句式 + 扰动机制
- expert-human-flavor-tiers（237行）：T1/T2/T3 Prompt + 严肃度1-10 + 感官优先级
- expert-character-dna（51行）：角色语言DNA模板

### 更新

- expert-anti-ai-taste → v2.2整合版（指向human-flavor协同）
- 框架集成：路由树/依赖图/协同协议 69/69 100%

---

## v1.10.1 — 2026-04-08

### 移除（含误删）

移除5个框架/工具类skill，其中：
- ✅ 合理移除：session-compactor、skill-lazy-loader、writing-assistant
- ❌ 误删：skill-safety-protocol、skill-deployment-protocol（本次v1.18.1补回）
