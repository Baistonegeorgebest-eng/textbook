---
name: skill-deployment-protocol
description: Skill部署集成规范。安装/批量导入/升级/删除skill后的强制性集成检查流程。覆盖路由树、路由规则、依赖图谱、协同协议、协作关系的全量联动验证。与skill-safety-protocol（写入安全）配对使用。
tags: [skill, deployment, integration, routing, dependency, collaboration, protocol]
version: "1.1"
type: meta-skill
category: skill-management
updated: "2026-04-03"
---

# Skill 部署集成规范（skill-deployment-protocol）

> **定位**：skill-safety-protocol 管"写入安全"（备份、验证、熔断），本 skill 管"集成完整"（框架联动、路由覆盖、依赖更新）。
>
> **触发条件**：用户要求"安装skill""批量导入""升级skill""删除skill""查重""集成检查"时激活。每次 skill 目录变更后必须执行本规范。
>
> **配对 skill**：skill-safety-protocol（前置）→ skill-deployment-protocol（后置）

---

## 一、前置：读取 skill-safety-protocol

执行本规范前，先读 `skill-safety-protocol/SKILL.md`，遵守其铁律（备份基准、写入验证）。

---

## 二、框架三件套定义

本规范的核心保护对象是三个框架文件，它们是整个小说 skill 体系的"操作系统"：

| 框架文件 | 职责 | 路径 |
|----------|------|------|
| **novel-expert-system** | 全流程调度中枢：路由树 + 路由规则 + 路由条目 + 质量门禁 | `~/.openclaw/skills/novel-expert-system/SKILL.md` |
| **expert-dependency-map** | 依赖图谱 + 学习路径 + 场景触发索引 | `~/.openclaw/skills/expert-dependency-map/SKILL.md` |
| **expert-collaboration-protocol** | 多 Expert 联动规则 + 调度协议 | `~/.openclaw/skills/expert-collaboration-protocol/SKILL.md` |

**任何 skill 目录变更后，这三个文件必须同步更新。**

---

## 三、检查清单

### 3.1 小说类 Skills（expert-* / novel-*）

对每个新安装/更新/删除的小说类 skill，逐项执行：

```
□ 1. 路由树节点
   │  文件：novel-expert-system
   │  操作：在专家团队分类树中添加/删除该 skill 的节点
   │  分类：题材主导 / 技能支撑 / 安全合规 / 题材拓展 / 学习成长
   │  例外：meta skills（collaboration-protocol / dependency-map）不需要路由树节点
   │
□ 2. 路由规则
   │  文件：novel-expert-system
   │  操作：添加/删除以该 skill 为主 Expert 或辅助 Expert 的调度规则
   │  格式：→ 场景名：skill-name（主）+ 辅助1 + 辅助2 + writing-safety
   │  要求：题材类必须有独立路由规则；技能类至少出现在某条规则的辅助列表中
   │
□ 3. 路由条目表
   │  文件：novel-expert-system
   │  操作：在路由表中添加/删除对应行
   │  格式：| 编号 | 场景 | 触发关键词 | 主Expert | 联动链 |
   │
□ 4. 依赖图谱表
   │  文件：expert-dependency-map
   │  操作：在依赖表中添加/删除该 skill 的一行（功能 + 适用阶段）
   │
□ 5. 学习路径
   │  文件：expert-dependency-map
   │  操作：在对应学习阶段（新手/进阶/高手）的推荐列表中添加/删除
   │
□ 6. 协同协议联动规则
   │  文件：expert-collaboration-protocol
   │  操作：添加/删除该 skill 的联动规则
   │  内容：主Expert→联动谁 / 被谁联动 / 联动顺序 / 触发条件
   │
□ 7. 相关 skills 的 SKILL.md 协作关系
   │  操作：
   │    - 新 skill 的 SKILL.md 末尾添加"与其他 Skills 的协作关系"章节
   │    - 被联动的已有 skills 的 SKILL.md 中添加对新 skill 的引用
   │
□ 8. 触发关键词
   │  操作：在路由条目和 frontmatter tags 中记录用户可能说的触发词
   │
□ 9. 统计数字
   │  操作：更新路由总数、覆盖维度、版本号
   │
□ 10. 覆盖率验证
    │  操作：执行一键检查命令（见 §六），确认输出为空
```

### 3.2 非小说类 Skills

```
□ 1. SKILL.md 完整性（frontmatter / 标题 / 章节结构）
□ 2. 功能重叠检查（description 关键词比对）
□ 3. 系统 available_skills 注册确认
```

---

## 四、批量导入 SOP

```
Step 0  前置检查
        ├─ 读取 skill-safety-protocol
        ├─ 备份 ~/.openclaw/skills/
        └─ 列出当前已安装清单

Step 1  解压 + 质检
        ├─ 解压到临时目录
        ├─ 检查 SKILL.md 存在 + 非空 + frontmatter 完整
        ├─ 内容质量检查（行数/章节/示例数）
        ├─ 功能重叠检查 → 移除低质量重叠
        └─ AIGC 水印扫描（ReservedCode/ProduceID/Signature/base64）

Step 2  安装
        └─ cp 到 ~/.openclaw/skills/

Step 3  框架集成（本规范核心）
        ├─ 小说类：执行 §3.1 全部 10 项
        └─ 通用类：执行 §3.2 全部 3 项

Step 4  验证
        ├─ 运行一键覆盖率检查
        └─ 确认输出为空 → 报告

Step 5  打包输出
        └─ 集成完成后再打包
```

---

## 五、删除 / 重命名 / 版本升级

### 5.1 删除 Skill

框架中残留引用 = "幽灵路由"，必须清理：

```
□ grep 框架三件套中所有引用
□ 路由树节点 → 删除
□ 路由规则 → 删除或替换为替代 skill
□ 路由条目 → 删除并重新编号
□ 依赖图谱 → 删除
□ 协同协议 → 删除联动规则
□ 其他 skills 的协作关系 → 删除引用
□ 更新统计数字
```

### 5.2 重命名

= 删除旧名 + 新增新名，同时执行 §5.1 + §3.1。

### 5.3 版本升级

不能只覆盖文件。检查新版本是否：
```
□ 新增了与其他 skills 的协作关系？
□ 修改了触发关键词或场景？
□ 改变了分类归属？
→ 以上任一为"是"，重新执行 §3.1 全量检查
```

---

## 六、一键覆盖率检查命令

```bash
cd ~/.openclaw/skills && \
echo "=== 集成覆盖率检查 ===" && \
ls -d expert-*/ novel-*/ 2>/dev/null | sed 's/\///' | sort > /tmp/_installed.txt && \
echo "已安装小说skills: $(wc -l < /tmp/_installed.txt)" && \
echo "" && \
echo "--- novel-expert-system 路由树 ---" && \
grep -oP 'expert-[a-z0-9-]+|novel-[a-z0-9-]+' novel-expert-system/SKILL.md | sort -u > /tmp/_tree.txt && \
miss1=$(comm -23 /tmp/_installed.txt /tmp/_tree.txt) && \
[ -z "$miss1" ] && echo "✅ 全覆盖" || echo "❌ 缺失: $miss1" && \
echo "" && \
echo "--- expert-dependency-map ---" && \
grep -oP 'expert-[a-z0-9-]+|novel-[a-z0-9-]+' expert-dependency-map/SKILL.md | sort -u > /tmp/_dep.txt && \
miss2=$(comm -23 /tmp/_installed.txt /tmp/_dep.txt) && \
[ -z "$miss2" ] && echo "✅ 全覆盖" || echo "❌ 缺失: $miss2" && \
echo "" && \
echo "--- expert-collaboration-protocol ---" && \
grep -oP 'expert-[a-z0-9-]+|novel-[a-z0-9-]+' expert-collaboration-protocol/SKILL.md | sort -u > /tmp/_collab.txt && \
miss3=$(comm -23 /tmp/_installed.txt /tmp/_collab.txt) && \
[ -z "$miss3" ] && echo "✅ 全覆盖" || echo "❌ 缺失: $miss3"
```

---

## 七、已知例外

| Skill | 不需要路由节点的原因 |
|-------|---------------------|
| expert-collaboration-protocol | 元协议，定义规则本身 |
| expert-dependency-map | 图谱本身 |
| expert-quickstart | 入口指南，非功能 Expert |

---

## 八、协作关系

### 与 skill-safety-protocol 的配对

| 阶段 | skill-safety-protocol | skill-deployment-protocol |
|------|----------------------|--------------------------|
| 前置 | ✅ 备份基准 / 写入验证 | — |
| 安装 | ✅ AIGC 检查 / 熔断 | — |
| 集成 | — | ✅ 路由/依赖/协同联动 |
| 验证 | — | ✅ 覆盖率验证 |

**顺序不可颠倒**：先 safety（安全）→ 后 deployment（集成）。

### 与 novel-expert-system 的关系

本 skill 是 novel-expert-system 的"运维手册"。novel-expert-system 是运行时调度器，本 skill 是变更时的集成规范。

---

*v1.0（2026-04-03）初始版本，skills3_extra 批量导入后的框架集成遗漏触发*
*v1.1（2026-04-03）补充：skill删除清理 / 重命名迁移 / AIGC详细清单 / 触发关键词 / 版本升级同步 / 变更日志*
