# novel-skills Changelog

## v1.18.1 — 2026-04-24

### 补回：封包铁律 skills（v1.10→v1.10.1 误删修复）

**背景**：v1.10 → v1.10.1 封包时，移除了5个"框架/工具类"skill。其中2个有实质内容且无替代品，被错误移除。本次补回。

**补回 skills：**

| skill | 行数 | 作用 | 补回理由 |
|-------|------|------|----------|
| skill-safety-protocol | 201行 | Skill写入安全规程（备份基准/写入验证/熔断） | 新agent无替代品，防止写入操作搞坏已有skill |
| skill-deployment-protocol | 224行 | Skill部署集成检查（路由树/依赖图/协同协议联动） | 与skill-safety-protocol配对，确保skill变更后框架完整 |

**不补回 skills（及理由）：**

| skill | 行数 | 理由 |
|-------|------|------|
| session-compactor | 365行 | 与AGENTS.md heartbeat机制 + context-manager重复 |
| skill-lazy-loader | 381行 | 耦合具体skill名称，版本迭代后易过时；待后续skill审查完再更新 |
| writing-assistant | 21行 | 纯壳子，被novel-writing-expert(474行)完全覆盖 |

**教训记录：**
> ⚠️ 封包时不能仅凭"是否为创作类skill"判断去留。框架/工具类skill需要评估：
> 1. 是否有独立价值（不与其他skill重复）
> 2. 新agent是否有替代能力
> 3. 移除后是否造成不可恢复的能力缺失
> 
> 本次 session-compactor 的误判就是因为把"小说进度快照"功能误认为已无替代品，
> 实际上 novel-memory-3layer 已有更精确的增量事实快照机制。
> 但 skill-safety-protocol 的"写入保护"能力确实没有替代品，属于误删。

### 封包铁律（新增）

> **每次封包前必须检查：**
> 1. skill-safety-protocol 存在 ✅
> 2. skill-deployment-protocol 存在 ✅
> 3. 两个skill的SKILL.md行数 ≥ 200行 ✅
> 
> 此铁律写入 CHANGELOG.md，后续封包必须继承。

---

## v1.18.0 — 2026-04-23

### 新增：人味协议v4.0拆分

- expert-human-flavor（499行）：三层人味模型 + 硬约束 + 缓冲句式 + 扰动机制
- expert-human-flavor-tiers（237行）：T1/T2/T3 Prompt + 严肃度1-10 + 感官优先级
- expert-character-dna（51行）：角色语言DNA模板

### 更新

- expert-anti-ai-taste → v2.2整合版（指向human-flavor协同）
- 框架集成：路由树/依赖图/协同协议 69/69 100%

---

## v1.10.1 — 2026-04-08

### 移除（含误删）

移除5个框架/工具类skill，其中：
- ✅ 合理移除：session-compactor、skill-lazy-loader、writing-assistant
- ❌ 误删：skill-safety-protocol、skill-deployment-protocol（本次v1.18.1补回）
